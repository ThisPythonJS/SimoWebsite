import { AddbotComponent } from "../../components/Addbot/Addbot";

export const Addbot: React.FC = () => {
    return <AddbotComponent/>;
};
