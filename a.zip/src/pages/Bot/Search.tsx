import React from 'react';
import { SearchComponent } from '../../components/Search/Search';

export const Search: React.FC = () => {
    return <SearchComponent />
};