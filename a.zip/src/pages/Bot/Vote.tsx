import React from "react";
import { VoteComponent } from "../../components/Vote/Vote";

export const Vote: React.FC = () => {
    return <VoteComponent/>
};
