import React from "react";
import { DashboardComponent } from "../../components/Dashboard/Dashboard";

export const Dashboard: React.FC = () => {
    return <DashboardComponent/>
};
