import { FC } from "react";
import { DashboardEdit } from "../../components/Dashboard/Edit";

export const DashboardEditPage: FC = () => {
    return <DashboardEdit/>
};