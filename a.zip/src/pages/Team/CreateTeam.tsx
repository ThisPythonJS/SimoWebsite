import { FC } from "react";
import { CreateTeam } from "../../components/Team/CreateTeam";

export const CreateTeamPage: FC = () => {
    return <CreateTeam/>
};