import { FC } from "react";
import { InviteComponent } from "../../components/Team/Invite";

export const InvitePage: FC = () => {
    return <InviteComponent/>
};