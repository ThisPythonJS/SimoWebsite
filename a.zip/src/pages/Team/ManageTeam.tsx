import { FC } from "react";
import { ManageTeamComponent } from "../../components/Team/ManageTeam";

export const ManageTeamPage: FC = () => {
    return <ManageTeamComponent/>
};