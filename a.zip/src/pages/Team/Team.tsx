import { FC } from "react";
import { TeamComponent } from "../../components/Team/Team";

export const TeamPage: FC = () => {
    return <TeamComponent/>
};